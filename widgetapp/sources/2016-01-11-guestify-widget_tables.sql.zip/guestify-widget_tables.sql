-- phpMyAdmin SQL Dump
-- version 4.2.6deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 01. Dez 2015 um 17:53
-- Server Version: 5.5.44-0ubuntu0.14.10.1
-- PHP-Version: 5.5.12-2ubuntu4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `guestify`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
`id` int(11) unsigned NOT NULL,
  `account_id` int(11) unsigned NOT NULL,
  `host_id` int(11) unsigned NOT NULL,
  `poll_id` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `period` varchar(30) NOT NULL,
  `format` varchar(30) NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `style` varchar(30) NOT NULL,
  `status` tinyint(5) unsigned NOT NULL DEFAULT '0',
  `views` int(11) unsigned NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hash` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `widgets`
--

INSERT INTO `widgets` (`id`, `account_id`, `host_id`, `poll_id`, `name`, `period`, `format`, `width`, `height`, `style`, `status`, `views`, `created`, `modified`, `deleted`, `hash`) VALUES
(1, 6, 7, 12, 'MyWidget', 'month_6', 'landscape', 500, 200, 'standard', 1, 13, '2015-11-11 15:08:51', '2015-12-01 16:26:17', 0, '587d5138fb8e1a6a35f6'),
(2, 6, 6, 11, 'hasenwidget', 'year_1', 'portrait', 200, 800, 'retro', 0, 0, '2015-11-11 15:09:36', '2015-11-23 12:02:06', 0, 'b4ac80f7d9e80b9c6bb6'),
(3, 6, 7, 12, 'MyWidget125', 'all', 'square', 350, 350, 'party', 0, 0, '2015-11-11 15:10:11', '2015-11-23 12:02:22', 0, 'e7133b9ee75cccafa614'),
(4, 6, 7, 12, 'newwidget', 'year_1', 'square', 300, 300, 'aquarell', 0, 0, '2015-11-16 10:49:02', '2015-11-23 12:02:33', 0, 'b20f5a0c20117f229022'),
(5, 6, 6, 11, 'newwidget', 'month_3', 'portrait', 100, 200, 'nubuck', 0, 0, '2015-11-20 11:31:34', '2015-11-23 12:02:45', 0, '33b1b9948c2edf2af24e'),
(6, 6, 6, 11, 'bet', 'week_1', 'portrait', 50, 70, 'nubuck', 0, 0, '2015-11-20 16:49:41', '2015-11-23 12:04:19', 0, '9143724aaf44d5bda6eb');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `widget_elements`
--

CREATE TABLE IF NOT EXISTS `widget_elements` (
`id` int(11) unsigned NOT NULL,
  `widget_id` int(11) unsigned NOT NULL,
  `type` varchar(30) NOT NULL,
  `param` varchar(30) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Daten für Tabelle `widget_elements`
--

INSERT INTO `widget_elements` (`id`, `widget_id`, `type`, `param`, `created`, `modified`, `deleted`) VALUES
(1, 1, 'gsi', '', '2015-11-11 15:08:51', '2015-11-19 16:09:21', 0),
(2, 1, 'ratingcount', '', '2015-11-11 15:08:52', '2015-11-19 16:11:09', 0),
(3, 1, 'ratinglabel', '', '2015-11-11 15:08:52', '2015-11-19 16:11:25', 0),
(4, 1, 'comment', 'last10', '2015-11-11 15:08:52', '2015-12-01 16:26:17', 0),
(5, 2, 'gsi', '', '2015-11-11 15:09:36', '2015-11-11 15:09:36', 0),
(6, 2, 'trend', '', '2015-11-11 15:09:36', '2015-11-11 15:09:36', 0),
(7, 2, 'ratingcount', '', '2015-11-11 15:09:37', '2015-11-11 15:09:37', 0),
(8, 2, 'ratinglabel', '', '2015-11-11 15:09:37', '2015-11-11 15:09:37', 0),
(9, 3, 'gsi', '', '2015-11-11 15:10:11', '2015-11-11 15:10:11', 0),
(10, 3, 'ratinglabel', '', '2015-11-11 15:10:11', '2015-11-11 15:10:11', 0),
(11, 3, 'comment', 'last5', '2015-11-11 15:10:11', '2015-11-23 12:02:22', 0),
(12, 4, 'gsi', '', '2015-11-16 10:49:02', '2015-11-16 10:49:02', 0),
(13, 4, 'trend', '', '2015-11-16 10:49:02', '2015-11-16 10:49:02', 0),
(14, 4, 'ratinglabel', '', '2015-11-16 10:49:02', '2015-11-16 10:49:02', 0),
(15, 1, 'trend', NULL, '2015-11-19 16:09:21', '2015-12-01 12:37:12', 0),
(16, 5, 'gsi', NULL, '2015-11-20 11:31:34', '2015-11-20 11:44:44', 0),
(17, 5, 'trend', NULL, '2015-11-20 11:31:35', '2015-11-20 11:44:44', 0),
(18, 5, 'comment', 'top5', '2015-11-20 11:31:35', '2015-11-23 12:02:45', 0),
(19, 5, 'ratinglabel', NULL, '2015-11-20 11:49:13', '2015-11-20 11:49:13', 0),
(20, 6, 'gsi', NULL, '2015-11-23 10:20:10', '2015-11-23 10:20:10', 0),
(21, 6, 'trend', NULL, '2015-11-23 10:20:10', '2015-11-23 11:54:17', 0),
(22, 6, 'comment', 'last5', '2015-11-23 10:20:23', '2015-11-23 11:54:17', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widget_elements`
--
ALTER TABLE `widget_elements`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `widget_elements`
--
ALTER TABLE `widget_elements`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
